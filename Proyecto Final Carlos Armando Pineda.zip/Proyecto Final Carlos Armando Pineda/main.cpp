#include <iostream>

using namespace std;

extern void inicio();

int main(int argc, char** argv) {
	
	inicio();
	
	return 0;
}

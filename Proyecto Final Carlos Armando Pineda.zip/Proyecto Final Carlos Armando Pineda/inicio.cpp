#include <iostream>
using namespace std;

extern void productos(int opcion);

extern void imprimirFactura();


void inicio()

{
	
	int opcion = 0;

while (true){
	
	system("cls");
	
	cout<<"*******";
	cout<<"Innovatech";
	cout<<"*******";
	cout<<endl;
	
	
	
	cout<<"1- Dispositivos Mobiles "<<endl;
	cout<<"2- Accesorios"<<endl;
	cout<<"3- Listado"<<endl;
	cout<<"4- Imprimir factura"<<endl;
	cout<<"0- Salir"<<endl;
	
	
	cout<<endl;
	cout<<"Seleccione una opcion: ";
	cin>> opcion;
	
	if (opcion == 0){
		
    break;		
	}
	
	if (opcion == 4){
		
		imprimirFactura();
			
	} else {
		
			productos(opcion);
	}
	

}

}


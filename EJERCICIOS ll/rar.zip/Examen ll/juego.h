#include <iostream>

using namespace std;

void inicializarArreglo();

void dificultad();

void gotoxy(int x,int y);

void pintar();

void dibujarcuerpo();

void guardarposicion();

void borrarcuerpo();

void Teclear(char &tecla);

void comida();

bool gameover();

void puntosx();

void proceso(char &tecla, int &puntos);
